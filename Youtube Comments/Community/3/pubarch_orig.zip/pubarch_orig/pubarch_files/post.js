addEventListener('load', function (e) {
    get_youtube_comments();
});
